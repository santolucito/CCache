#define COMPRESS_ID		6

#define DDBITS			1
#define CLEVEL			5
#include "compr1c.h"

