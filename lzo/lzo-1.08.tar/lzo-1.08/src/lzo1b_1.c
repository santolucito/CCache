#define COMPRESS_ID		1

#define DDBITS			0
#define CLEVEL			1
#include "compr1b.h"

